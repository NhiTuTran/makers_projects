class PasswordManager
end
